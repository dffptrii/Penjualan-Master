package com.ryz.exampactivity;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

public class DetailActivity2 extends AppCompatActivity implements View.OnClickListener {

    Button btnHapus, btnKeluar;
    TextView tvNamaPembeli, tvNamaBarang, tvJmlBarang, tvHarga, tvUangBayar,
            tvTotal, tvKembalian, tvBonus, tvKeterangan;

    double jmlBarang, hrgBarang, uangByr, total, kembalian;
    String namaPelanggan, namaBarang, jumlahBarang, hargaBarang, uangBayar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_detail2);

        //TextView
        tvNamaPembeli = findViewById(R.id.tvNamaPembeli);
        tvNamaBarang = findViewById(R.id.tvNamaBarang);
        tvJmlBarang = findViewById(R.id.tvJmlBarang);
        tvHarga = findViewById(R.id.tvHarga);
        tvUangBayar = findViewById(R.id.tvUangBayar);
        tvTotal = findViewById(R.id.tvTotal);
        tvKembalian = findViewById(R.id.tvKembalian);
        tvBonus = findViewById(R.id.tvBonus);
        tvKeterangan = findViewById(R.id.tvKeterangan);

        // Button
        btnHapus = findViewById(R.id.btnHapus);
        btnKeluar = findViewById(R.id.btnKeluar);

        btnHapus.setOnClickListener(this);
        btnKeluar.setOnClickListener(this);

        Bundle extras = getIntent().getExtras();

        try {
            namaPelanggan = extras.getString("NamaPel");
            namaBarang = extras.getString("NamaBarang");
            jumlahBarang = extras.getString("JumlahBarang");
            hargaBarang = extras.getString("HargaBarang");
            uangBayar = extras.getString("UangBayar");

            jmlBarang = Double.parseDouble(jumlahBarang);
            hrgBarang = Double.parseDouble(hargaBarang);
            uangByr = Double.parseDouble(uangBayar);
            total = (jmlBarang * hrgBarang);

            tvNamaPembeli.setText("Nama Pembeli : " + namaPelanggan);
            tvNamaBarang.setText("Nama Barang : " + namaBarang);
            tvJmlBarang.setText("Jumlah Barang : " + jumlahBarang);
            tvHarga.setText("Harga Barang : " + hargaBarang);
            tvUangBayar.setText("Uang bayar : " + uangBayar);

            tvTotal.setText("Total Belanja " + total);
            if (total >= 200000) {
                tvBonus.setText("Bonus : HardDisk 1TB");
            } else if (total >= 50000) {
                tvBonus.setText("Bonus : Keyboard Gaming");
            } else if (total >= 40000) {
                tvBonus.setText("Bonus : Mouse Gaming");
            } else {
                tvBonus.setText("Bonus : Tidak ada bonus!");
            }

            kembalian = (uangByr - total);
            if (uangByr < total) {
                tvKeterangan.setText("Keterangan : Uang bayar kurang Rp. " + (-kembalian));
                tvKembalian.setText("Uang Kembalian : Rp. 0");
            } else {
                tvKeterangan.setText("Keterangan : Tunggu kembalian atau tunggu Hadiah kalo tidak ada sudah selesai");
                tvKembalian.setText("Uang Kembalian : Rp. " + kembalian);
            }

        } catch (NullPointerException e) {
            Toast.makeText(this, "Data kosong", Toast.LENGTH_SHORT).show();
        }

    }

    @Override
    public void onClick(View view) {

        if (view.getId() == R.id.btnHapus) {
            tvNamaPembeli.setText("");
            tvNamaBarang.setText("");
            tvJmlBarang.setText("");
            tvHarga.setText("");
            tvUangBayar.setText("");
            tvKembalian.setText("");
            tvKeterangan.setText("");
            tvBonus.setText("");
            tvTotal.setText("");

            Toast.makeText(getApplicationContext(), "Data sudah dihapus", Toast.LENGTH_SHORT).show();

        } else if (view.getId() == R.id.btnKeluar) {
            moveTaskToBack(true);
        }
    }
}