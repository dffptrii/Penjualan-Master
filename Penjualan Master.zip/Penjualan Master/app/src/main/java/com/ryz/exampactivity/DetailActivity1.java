package com.ryz.exampactivity;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class DetailActivity1 extends AppCompatActivity implements View.OnClickListener {

    EditText etNamaPelanggan, etNamaBarang, etJmlBarang, etHarga, etJmlUang;

    Button btnProses;

    String namaPelanggan, namaBarang, jumlahBarang, hargaBarang, uangBayar;




    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_detail1);

        getSupportActionBar().setTitle("Transaksi Toko Komputer");

        //EditText
        etNamaPelanggan = findViewById(R.id.etNamaPelanggan);
        etNamaBarang = findViewById(R.id.etNamaBarang);
        etJmlBarang = findViewById(R.id.etJmlBarang);
        etHarga = findViewById(R.id.etHarga);
        etJmlUang = findViewById(R.id.etJmlUang);

        //Button
        btnProses = findViewById(R.id.btnProses);

        btnProses.setOnClickListener(this);

    }

    @Override
    public void onClick(View view) {
        if (view.getId() == R.id.btnProses) {

            boolean isEmptyField = false;

            Intent i = new Intent(DetailActivity1.this, DetailActivity2.class);
            namaPelanggan = etNamaPelanggan.getText().toString().trim();
            namaBarang = etNamaBarang.getText().toString().trim();
            jumlahBarang = etJmlBarang.getText().toString().trim();
            hargaBarang = etHarga.getText().toString().trim();
            uangBayar = etJmlUang.getText().toString().trim();

            if (TextUtils.isEmpty(namaPelanggan)) {
                isEmptyField = true;
                etNamaPelanggan.setError("Tidak boleh kosong!!!");
            }

            if (TextUtils.isEmpty(namaBarang)) {
                isEmptyField = true;
                etNamaBarang.setError("Tidak boleh kosong!!!");
            }

            if (TextUtils.isEmpty(jumlahBarang)) {
                isEmptyField = true;
                etJmlBarang.setError("Tidak boleh kosong!!!");
            }

            if (TextUtils.isEmpty(hargaBarang)) {
                isEmptyField = true;
                etHarga.setError("Tidak boleh kosong!!!");
            }

            if (TextUtils.isEmpty(uangBayar)) {
                isEmptyField = true;
                etJmlUang.setError("Tidak boleh kosong!!!");
            }

            if (!isEmptyField) {
                i.putExtra("NamaPel", namaPelanggan);
                i.putExtra("NamaBarang", namaBarang);
                i.putExtra("JumlahBarang", jumlahBarang);
                i.putExtra("HargaBarang", hargaBarang);
                i.putExtra("UangBayar", uangBayar);
                startActivity(i);
                finish();
            }
        }
    }
}