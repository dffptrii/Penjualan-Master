package com.ryz.exampactivity;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // deklarasi variabel dengan memanggil id yang berada pada layout activity main
        Button MoveActivity1 = findViewById(R.id.btn_moveActivity1);
        Button MoveActivity2 = findViewById(R.id.btn_moveActivity2);

        // set onclick
        MoveActivity1.setOnClickListener(this);
        MoveActivity2.setOnClickListener(this);

    }

    // method untuk mengarahkan ke activity barunya
    @Override
    public void onClick(View view) {
        // condition
        // jika onclick nya sama dengan id moveactivity1
        // maka panggil kelas DetailActivity1
        if (view.getId() == R.id.btn_moveActivity1) {
            Intent moveIntent1 = new Intent(MainActivity.this, DetailActivity1.class);
            startActivity(moveIntent1);
        }
        // jika onclick nya sama dengan id moveactivity2
        // maka panggil kelas DetailActivity2
        else if (view.getId() == R.id.btn_moveActivity2) {
            Intent moveIntent2 = new Intent(MainActivity.this, DetailActivity2.class);
            startActivity(moveIntent2);
        }
    }
}